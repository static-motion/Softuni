﻿using System;

namespace SimpleMVC.App.MVC.Attributes.Security
{
    public class SecurityAttribute : Attribute
    {

    }
}
